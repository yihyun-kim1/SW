class Flag:
    def __init__(self):
        self
    def drawFlag(self):
        pass