import Shape
import Info
import Flag

class Greece(Flag.Flag):
    def __init__(self):
        self.rect = Shape.Rectangle()

    def drawFlag(self):
        #초기 위치로 이동
        Info.t.shape('turtle')
        Info.t.color("white")
        Info.t.goto(Info.sx,Info.sy)
        Info.t.speed(30)

        self.rect.drawShape(Info.width,Info.height,"","white",0) # 흰색 바탕으로 칠함

        ##그리스 국기 파란 줄
        for i in range(0,9,2):
            Info.t.sety(Info.sy-(Info.height/9)*i)
            self.rect.drawShape(Info.width,(Info.height/9),"","blue",0)

        #파란 박스
        Info.t.color("")
        Info.t.goto(Info.sx,Info.sy)
        self.rect.drawShape(((Info.height/9)*5),((Info.height/9)*5),"","blue",0)

        #십자가 그리기
        Info.t.color("")
        Info.t.goto(Info.sx+((Info.height/9)*2),Info.sy)
        Info.t.color("white")
        self.rect.drawShape((Info.height/9),((Info.height/9)*5),"white","white",0)

        Info.t.color("")
        Info.t.goto(Info.sx,Info.sy-((Info.height/9)*2))
        Info.t.color("white")
        self.rect.drawShape(((Info.height/9)*5),(Info.height/9),"white","white",0)

        Info.t.hideturtle()
        Info.time.sleep(3)
        Info.t.clear()
        Info.t.reset()
        Info.t.done