import turtle as t
import time

width = 300
height = 200

sx = -150
sy = 100
