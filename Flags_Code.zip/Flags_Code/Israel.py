import Shape
import Info
import Flag

class Israel(Flag.Flag):
    def __init__(self):
        self.rect = Shape.Rectangle()
        self.trianglesize = 50

    def drawFlag(self):
        # 초기 위치로 이동
        Info.t.shape('turtle')
        Info.t.color("white")
        Info.t.goto(Info.sx, Info.sy)
        Info.t.speed(30)

        # 국기 틀 그리기
        self.rect.drawShape(Info.width, Info.height, "black", "white",0)

        # 위, 아래 파란 선 그리기 - 터틀 현재 위치 (왼쪽 모서리에서 오른쪽 바라봄)
        Info.t.sety(Info.sy - (Info.height / 10)) # 윗줄
        self.rect.drawShape(Info.width, Info.height / 5, "blue", "blue",0)
        Info.t.color("")
        Info.t.sety(Info.sy - ((Info.height / 10) * 7)) # 아랫줄
        self.rect.drawShape(Info.width, Info.height / 5, "blue", "blue",0)
        Info.t.color("")

        # 삼각형 그리기
        Info.t.setx(0)
        Info.t.sety(Info.height / 7)

        Info.t.color("blue")
        Info.t.pensize(5)
        Info.t.right(120)
        for i in range(3):
            Info.t.forward(50)
            Info.t.left(120)

        Info.t.pensize(1)
        Info.t.color("")
        Info.t.setx(-self.trianglesize / 2)
        Info.t.sety(Info.height / 7 - self.trianglesize / 3)
        Info.t.color("blue")
        Info.t.setheading(0)
        Info.t.pensize(5)
        for i in range(3):
            Info.t.forward(50)
            Info.t.right(120)

        Info.t.hideturtle()
        Info.time.sleep(3)
        Info.t.clear()
        Info.t.reset()
        Info.t.done