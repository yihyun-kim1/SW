import Shape
import Info
import Flag

class Korea(Flag.Flag):
    def __init__(self):
        self.rect = Shape.Rectangle()
        self.circle = Shape.Circle()
        self.dia = 100 # 태극 지름 = 세로의 1/2 = 100 = self.diameter

    def drawFlag(self):
        # 초기 위치로 이동
        Info.t.shape('turtle')
        Info.t.color("white")
        Info.t.goto(Info.sx, Info.sy)
        Info.t.speed(30)

        self.rect.drawShape(Info.width, Info.height, "black", "white",0) # 흰색 바탕으로 칠함

        # 건곤감리 그리기 (막대기 세로 길이 : (self.dia/2), 가로 길이 : (self.dia/12)
        # 건
        Info.t.color("")
        Info.t.setx(Info.sx + 45)
        Info.t.sety(Info.sy - 61)
        self.rect.drawShape(self.dia / 12, self.dia / 2, "black", "black", 143.5)
        Info.t.color("")
        Info.t.setx(Info.sx + 45 + (self.dia / 24) * 3)
        Info.t.sety(Info.sy - 71)
        self.rect.drawShape(self.dia / 12, self.dia / 2, "black", "black", 143.5)
        Info.t.color("")
        Info.t.setx(Info.sx + 45 + (self.dia / 24) * 6)
        Info.t.sety(Info.sy - 81)
        self.rect.drawShape(self.dia / 12, self.dia / 2, "black", "black", 143.5)

        # 리
        Info.t.color("")
        Info.t.setx(Info.sx + 35)
        Info.t.sety(-40)
        self.rect.drawShape(self.dia / 12, self.dia / 2, "black", "black", 33.5)

        Info.t.color("")
        Info.t.setx(Info.sx + 35 + (self.dia / 24) * 3)
        Info.t.sety(-32)
        self.rect.drawShape(self.dia / 12, self.dia / 5, "black", "black", 33.5)

        Info.t.color("")
        Info.t.setx(Info.sx + 52 + (self.dia / 24) * 3)
        Info.t.sety(-57)
        self.rect.drawShape(self.dia / 12, self.dia / 5, "black", "black", 33.5)

        Info.t.color("")
        Info.t.setx(Info.sx + 35 + (self.dia / 24) * 6)
        Info.t.sety(-24)
        self.rect.drawShape(self.dia / 12, self.dia / 2, "black", "black", 33.5)

        # 태극 문양
        Info.t.color("")
        Info.t.setx(28)
        Info.t.sety(-40)
        Info.t.pensize(2)
        self.circle.drawShape(50, 360, "red", "red")

        Info.t.color("")
        Info.t.setx(Info.sx + 100)
        Info.t.sety(Info.sy - 100)
        Info.t.setheading(270)
        self.circle.drawShape(50, 180, "blue", "blue")

        Info.t.color("")
        Info.t.setx(Info.sx + 200)
        Info.t.sety(Info.sy - 100)
        Info.t.setheading(90)
        self.circle.drawShape(25, 180, "blue", "blue")

        Info.t.color("")
        Info.t.setx(Info.sx + 100)
        Info.t.sety(Info.sy - 100)
        Info.t.setheading(-90)
        self.circle.drawShape(25, 180, "blue", "red")

        # 감
        Info.t.color("")
        Info.t.setx(49)
        Info.t.sety(62)
        self.rect.drawShape(self.dia / 12, self.dia / 5, "black", "black", 33.5)

        Info.t.color("")
        Info.t.setx(65)
        Info.t.sety(37)
        self.rect.drawShape(self.dia / 12, self.dia / 5, "black", "black", 33.5)

        Info.t.color("")
        Info.t.setx(62)
        Info.t.sety(70)
        self.rect.drawShape(self.dia / 12, self.dia / 2, "black", "black", 33.5)

        Info.t.color("")
        Info.t.setx(76)
        Info.t.sety(78)
        self.rect.drawShape(self.dia / 12, self.dia / 5, "black", "black", 33.5)

        Info.t.color("")
        Info.t.setx(92)
        Info.t.sety(54)
        self.rect.drawShape(self.dia / 12, self.dia / 5, "black", "black", 33.5)

        # 곤
        Info.t.color("")
        Info.t.setx(70)
        Info.t.sety(-40)
        self.rect.drawShape(self.dia / 12, self.dia / 5, "black", "black", 143.5)

        Info.t.color("")
        Info.t.setx(53)
        Info.t.sety(-64)
        self.rect.drawShape(self.dia / 12, self.dia / 5, "black", "black", 143.5)

        Info.t.color("")
        Info.t.setx(70 + (self.dia / 24) * 3)
        Info.t.sety(-48)
        self.rect.drawShape(self.dia / 12, self.dia / 5, "black", "black", 143.5)

        Info.t.color("")
        Info.t.setx(53 + (self.dia / 24) * 3)
        Info.t.sety(-72)
        self.rect.drawShape(self.dia / 12, self.dia / 5, "black", "black", 143.5)

        Info.t.color("")
        Info.t.setx(70 + (self.dia / 24) * 6)
        Info.t.sety(-56)
        self.rect.drawShape(self.dia / 12, self.dia / 5, "black", "black", 143.5)

        Info.t.color("")
        Info.t.setx(53 + (self.dia / 24) * 6)
        Info.t.sety(-80)
        self.rect.drawShape(self.dia / 12, self.dia / 5, "black", "black", 143.5)

        Info.t.hideturtle()
        Info.time.sleep(3)
        Info.t.clear()
        Info.t.reset()
        Info.t.done