import Shape
import Info
import Flag

class RabbitKingdom(Flag.Flag):
    def __init__(self):
        self.rect = Shape.Rectangle()
        self.circle = Shape.Circle()

    def drawFlag(self):
        #초기 위치로 이동
        Info.t.shape('turtle')
        Info.t.color("white")
        Info.t.goto(Info.sx,Info.sy)
        Info.t.speed(30)

        #토끼 왕국 국기 틀
        self.rect.drawShape(Info.width,Info.height,"black","mistyrose",0)

        #토끼 왼쪽 귀
        Info.t.color("")
        Info.t.setx(Info.sx+((Info.width/10)*3))
        Info.t.sety(Info.sy-Info.height/4)
        self.rect.drawShape(Info.width/10,Info.height/4,"black","pink",0)

        #토끼 왼쪽 귓바퀴
        Info.t.color("")
        Info.t.setx(Info.sx+((Info.width/10)*3)+(Info.width/20))
        Info.t.sety(Info.sy-((Info.height/4)+Info.height/8))
        self.rect.drawShape(Info.width/20,Info.height/8,"","mistyrose",0)

        #토끼 오른쪽 귀
        Info.t.color("")
        Info.t.setx(Info.sx+((Info.width/10)*5))
        Info.t.sety(Info.sy-Info.height/4)
        self.rect.drawShape(Info.width/10,Info.height/4,"black","pink",0)

        #토끼 오른쪽 귓바퀴
        Info.t.color("")
        Info.t.setx(Info.sx+((Info.width/10)*5)+(Info.width/20))
        Info.t.sety(Info.sy-((Info.height/4)+Info.height/8))
        self.rect.drawShape(Info.width/20,Info.height/8,"","mistyrose",0)

        #토끼 얼굴
        Info.t.color("")
        Info.t.setx(Info.sx+((Info.width/10)*3))
        Info.t.sety(Info.sy-(Info.height/4)*2)
        self.rect.drawShape((Info.width/10)*3,Info.height/4,"black","pink",0)

        #토끼 안경
        Info.t.color("")
        Info.t.setx(Info.sx+((Info.width/10)*4))
        Info.t.sety(Info.sy-(Info.height/4)*2.5)
        Info.t.pensize(2)
        self.circle.drawShape((Info.width/10)/3,360,"white","")
        Info.t.color("")
        Info.t.forward(Info.width/10)
        Info.t.pensize(2)
        self.circle.drawShape((Info.width/10)/3,360,"white","")

        #토끼 안경 줄
        Info.t.color("")
        Info.t.setx(Info.sx+((Info.width/10)*4.3))
        Info.t.sety(Info.sy-((Info.height/4)*2)-(Info.height/12))
        Info.t.color("white")
        Info.t.forward((Info.width/10)/3)

        #토끼 코
        Info.t.color("")
        Info.t.setx(Info.sx+((Info.width/10)*3)+((Info.width/10)*3)/2)
        Info.t.sety(Info.sy-((Info.height/4)*2)-(Info.height/6))
        Info.t.color("mistyrose")
        Info.t.pensize(1)
        Info.t.begin_fill()
        Info.t.circle(4)
        Info.t.end_fill()
        Info.t.right(90)
        Info.t.forward(10)

        #토끼 당근 이파리
        Info.t.pensize(1)
        Info.t.color("")
        Info.t.setx(Info.sx+((Info.width/10)*7)+8)
        Info.t.sety(Info.sy-((Info.height/4)*2.5)+Info.height/20)
        self.rect.drawShape(Info.width/20,Info.height/20,"green","green",0)

        #토끼 당근
        Info.t.pensize(1)
        Info.t.color("")
        Info.t.setx(Info.sx+((Info.width/10)*7))
        Info.t.sety(Info.sy-(Info.height/4)*2.5)
        self.rect.drawShape(Info.width/10,Info.height/4,"black","orange",0)

        Info.t.sety(Info.sy-((Info.height/4)*2.5)-10)
        Info.t.setheading(0)
        Info.t.forward(10)
        Info.t.setx(Info.sx+((Info.width/10)*7))
        Info.t.sety(Info.sy-((Info.height/4)*2.5)-30)
        Info.t.forward(10)

        Info.t.hideturtle()
        Info.time.sleep(3)
        Info.t.clear()
        Info.t.reset()
        Info.t.done