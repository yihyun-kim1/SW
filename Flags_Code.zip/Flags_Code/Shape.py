import Info
import turtle as t

class Shape:
    def drawShape(self):
        pass

class Rectangle(Shape):
    def drawShape(self,width, height, linecolor, fillcolor, angle):
        t.setheading(angle)
        t.color(linecolor, fillcolor)
        t.begin_fill()
        t.forward(width)
        t.right(90)
        t.forward(height)
        t.right(90)
        t.forward(width)
        t.right(90)
        t.forward(height)
        t.right(90)
        t.end_fill()

class Stars(Shape):
    def drawShape(self,line, color):
        t.begin_fill()
        t.color(color)
        t.setheading(90) # 거북이 방향 위쪽
        t.right(150)
        t.forward(line)
        t.setheading(0) # 거북이 방향 오른쪽

        n = 5
        for i in range(n):
            t.forward(line)
            t.right((360 / n) * 2)
            t.forward(line)
            t.left(360 / n)

        t.end_fill()

class Circle(Shape):
    def drawShape(self,radius, extent, linecolor, fillcolor):
        t.color(linecolor, fillcolor)
        t.begin_fill()
        t.circle(radius, extent)
        t.end_fill()
