import Shape
import Info
import Flag

class Syria(Flag.Flag):
    def __init__(self):
        self.rect = Shape.Rectangle()
        self.star = Shape.Stars()

    def drawFlag(self):
        # 초기 위치로 이동
        Info.t.shape('turtle')
        Info.t.color("white")
        Info.t.goto(Info.sx, Info.sy)
        Info.t.speed(30)

        # 시리아 국기 중 맨 위 빨간 줄
        self.rect.drawShape(Info.width, Info.height / 3, "black", "red",0)

        # 시리아 국기 중 가운데 흰 줄
        Info.t.sety(Info.sy - (Info.height / 3))
        self.rect.drawShape(Info.width, Info.height / 3, "black", "white",0)

        # 시리아 국기 중 마지막 검은 줄
        Info.t.sety(Info.sy - ((Info.height / 3) * 2))
        self.rect.drawShape(Info.width, Info.height / 3, "black", "black",0)
        Info.t.color("") # 투명 선

        # 첫 번째 별 그리기
        Info.t.setx(Info.sx + Info.width / 3)
        Info.t.sety(Info.sy - (Info.height / 3 + 15))
        self.star.drawShape(12, "green")

        # 두 번째 별 그리기
        Info.t.color("") # 투명 선
        Info.t.setx(Info.sx + ((Info.width / 3) * 2))
        Info.t.sety(Info.sy - (Info.height / 3 + 15))
        self.star.drawShape(12, "green")

        Info.t.hideturtle()
        Info.time.sleep(3)
        Info.t.clear()
        Info.t.reset()
        Info.t.done