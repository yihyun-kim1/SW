import Shape
import Info
import Flag

class USA(Flag.Flag):
    def __init__(self):
        self.rect = Shape.Rectangle()
        self.star = Shape.Stars()

    def drawFlag(self):
        # 초기 위치로 이동
        Info.t.shape('turtle')
        Info.t.color("white")
        Info.t.goto(Info.sx, Info.sy)
        Info.t.speed(30)

        self.rect.drawShape(Info.width, Info.height, "black", "white",0) # 흰색 바탕으로 칠함

        # 빨간 줄 그리기
        for i in range(0, 13, 2):
            Info.t.sety(Info.sy - (Info.height / 13) * i)
            self.rect.drawShape(Info.width, (Info.height / 13), "black", "red",0)

        # 남색 박스
        Info.t.color("")
        Info.t.goto(Info.sx, Info.sy)
        self.rect.drawShape((Info.width / 5) * 2, ((Info.height / 13) * 7), "black", "navy",0)

        # 별 6개짜리 줄
        gapY = 1
        for i in range(0, 5):
            gapX = 1
            for j in range(0, 6):
                Info.t.color("") # 투명 선
                Info.t.setx(Info.sx + (Info.width / 20) * gapX)
                Info.t.sety(Info.sy - (Info.height / 26) * gapY)
                self.star.drawShape(4, "white")
                gapX += 1.2
            gapY += 2.7

        # 별 5개짜리 줄
        gapY = 2.2
        for i in range(0, 4):
            gapX = 1.6
            for j in range(0, 5):
                Info.t.color("") # 투명 선
                Info.t.setx(Info.sx + (Info.width / 20) * (gapX))
                Info.t.sety(Info.sy - (Info.height / 26) * (gapY))
                self.star.drawShape(4, "white")
                gapX += 1.2
            gapY += 2.7

        Info.t.hideturtle()
        Info.time.sleep(3)
        Info.t.clear()
        Info.t.reset()
        Info.t.done