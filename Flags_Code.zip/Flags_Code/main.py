import Syria
import Israel
import USA
import Greece
import RabbitKingdom
import Korea
from tkinter.simpledialog import *
import turtle as t
import time

inStr = ''
swidth, sheight = 500, 500
syria = Syria.Syria()
israel = Israel.Israel()
usa = USA.USA()
greece = Greece.Greece()
rabbitkingdom = RabbitKingdom.RabbitKingdom()
korea = Korea.Korea()

def input() :
    inStr = askstring('국가 고르기',
                      '**그리고 싶은 국기 번호 선택**\n\n1.대한민국\n2.토끼왕국\n3.그리스\n4.시리아\n5.이스라엘\n6.미국\n7.모든 국기\n8.종료\n')
    return inStr

def printFlag(instr) :
    if instr == 1 : #대한민국
        korea.drawFlag()
    elif instr == 2 : #토끼왕국
        rabbitkingdom.drawFlag()
    elif instr == 3 : #그리스
        greece.drawFlag()
    elif instr == 4 : #시리아
        syria.drawFlag()
    elif instr == 5 : #이스라엘
        israel.drawFlag()
    elif instr == 6 : #미국
        usa.drawFlag()
    elif instr == 7:  #모든 국기
        korea.drawFlag()
        rabbitkingdom.drawFlag()
        greece.drawFlag()
        syria.drawFlag()
        israel.drawFlag()
        usa.drawFlag()
    elif instr == 8:  #종료
        return False

    return True

if __name__ == "__main__" :
    t.title('국기 그리기')
    t.setup(width = swidth + 50, height = sheight + 50)
    t.screensize(swidth, sheight)

    while(True):
        inStr = input()
        if(printFlag(int(inStr))==False):
            break




